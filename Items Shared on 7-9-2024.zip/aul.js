function sapaan() {
    document.getElementById("sapaan").scrollIntoView();
}
function profile() {
    document.getElementById("profile").scrollIntoView();
}
function aboutme() {
    document.getElementById("aboutme").scrollIntoView();
}

function skil() {
    document.getElementById("skil").scrollIntoView();
}
function kontak() {
    document.getElementById("kontak").scrollIntoView();
}